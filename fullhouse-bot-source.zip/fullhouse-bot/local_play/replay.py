"""Build read-only replay frames from archived public events."""

import copy


def build_replay(hand, viewer):
    seats = hand["seats"]
    state = {
        "street": "preflop",
        "board": [],
        "pot": 0,
        "actor": None,
        "players": [
            {
                "id": bid,
                "name": hand.get("participants", {}).get(bid, {}).get("name", bid),
                "stack": hand["starting_stacks"][bid],
                "bet": 0,
                "status": "active",
                "dealer": bid == hand["dealer"],
                "cards": hand["hole_cards"][bid] if bid == viewer else [],
            }
            for bid in seats
        ],
    }
    frames = []

    def save(label):
        frames.append({**copy.deepcopy(state), "label": label})

    def street(board, name):
        state.update(board=list(board), street=name, actor=None)
        for p in state["players"]:
            p["bet"] = 0
        save({"flop": "发出翻牌", "turn": "发出转牌", "river": "发出河牌"}[name])

    save("开始一手 · 发底牌")
    for event in hand["result"].get("events", []):
        kind = event["type"]
        if kind == "street_start":
            if event["street"] != "preflop":
                street(event["community_cards"], event["street"])
        elif kind in ("blind", "action"):
            player = next(p for p in state["players"] if p["id"] == event["bot_id"])
            action = event["action"]
            paid = (
                event["amount"]
                if kind == "blind"
                else player["stack"] - event["stack_after"]
            )
            player["stack"] -= paid
            player["bet"] += paid
            if action == "fold":
                player["status"] = "folded"
            elif player["stack"] == 0:
                player["status"] = "all_in"
            state.update(actor=player["id"], pot=state["pot"] + paid)
            text = {
                "small_blind": "小盲",
                "big_blind": "大盲",
                "fold": "弃牌",
                "check": "过牌",
                "call": "跟注",
                "raise": "加注到",
                "all_in": "全下到",
            }[action]
            save(
                f"{player['name']} · {text}"
                + (f" {event['amount']}" if event["amount"] else "")
            )
        elif kind in ("showdown", "uncontested_win"):
            # All-in runouts omit some street_start events; reconstruct each street.
            board = hand["result"]["community_cards"]
            for n, name in [(3, "flop"), (4, "turn"), (5, "river")]:
                if len(state["board"]) < n <= len(board):
                    street(board[:n], name)
            for p in state["players"]:
                if p["id"] != viewer:
                    p["cards"] = (
                        hand["result"].get("revealed_cards", {}).get(p["id"], [])
                    )
            state["actor"] = None
            save("摊牌" if kind == "showdown" else "其他玩家弃牌，无需亮牌")
    # Settlement uses stored final stacks, so side-pot awards and odd chips agree exactly.
    state["pot"] = 0
    for p in state["players"]:
        p["stack"] = hand["result"]["final_stacks"][p["id"]]
        p["bet"] = 0
    state["actor"] = None
    save(
        "结算 · "
        + "，".join(
            f"{w['bot_id']} 获得 {w['amount']}" for w in hand["result"]["winners"]
        )
    )
    return {"viewer": viewer, "frames": frames}
