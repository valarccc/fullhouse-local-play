"""Durable completed-hand archive and observation-only decision exports."""

import json
import sqlite3
from pathlib import Path


class History:
    def __init__(self, path):
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        self.path = str(path)
        with sqlite3.connect(self.path) as db:
            db.execute(
                "CREATE TABLE IF NOT EXISTS hands (id TEXT PRIMARY KEY, finished TEXT NOT NULL, delta INTEGER NOT NULL, payload TEXT NOT NULL)"
            )

    def save_rebuy(self, record):
        with sqlite3.connect(self.path) as db:
            db.execute(
                "CREATE TABLE IF NOT EXISTS rebuys (id TEXT PRIMARY KEY, payload TEXT NOT NULL)"
            )
            db.execute(
                "INSERT INTO rebuys VALUES (?, ?)",
                (record["id"], json.dumps(record, ensure_ascii=False)),
            )

    def save(self, record):
        with sqlite3.connect(self.path) as db:
            db.execute(
                "INSERT OR IGNORE INTO hands VALUES (?, ?, ?, ?)",
                (
                    record["id"],
                    record["finished_at"],
                    record["chip_delta"].get("you", 0),
                    json.dumps(record, ensure_ascii=False),
                ),
            )

    def records(self):
        with sqlite3.connect(self.path) as db:
            return [
                json.loads(row[0])
                for row in db.execute(
                    "SELECT payload FROM hands ORDER BY finished DESC, id DESC"
                )
            ]

    def summary(self):
        records = self.records()
        total = sum(r["chip_delta"].get("you", 0) for r in records)
        return {
            "hands": len(records),
            "net_chips": total,
            "net_bb": total / 100,
            "bb100": total / len(records) if records else 0,
            "profitable_hands": sum(r["chip_delta"].get("you", 0) > 0 for r in records),
            "records": [
                {
                    "id": r["id"],
                    "finished_at": r["finished_at"],
                    "hand": r["hand"],
                    "session": r["session"],
                    "delta": r["chip_delta"].get("you", 0),
                    "board": r["result"]["community_cards"],
                    "pot": r["result"]["pot"],
                }
                for r in records
            ],
        }

    def export(self, training=False):
        rows = []
        for hand in reversed(self.records()):
            if training:
                for step, decision in enumerate(hand["decisions"]):
                    bid = decision["player"]
                    rows.append(
                        {
                            "schema_version": 1,
                            "hand_id": hand["id"],
                            "session": hand["session"],
                            "step": step,
                            **decision,
                            "hand_return_chips": hand["chip_delta"][bid],
                            "hand_return_bb": hand["chip_delta"][bid] / 100,
                            "last_decision_by_player": not any(
                                d["player"] == bid
                                for d in hand["decisions"][step + 1 :]
                            ),
                        }
                    )
            else:
                rows.append(hand)
        return "".join(json.dumps(r, ensure_ascii=False) + "\n" for r in rows).encode()
