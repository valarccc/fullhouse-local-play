"""Local accounts with salted password hashes and revocable cookie sessions."""

import hashlib
import hmac
import re
import secrets
import sqlite3
import time
from uuid import uuid4

from local_play.replay import build_replay
from local_play.style_stats import summarize_style


class Accounts:
    def __init__(self, path):
        self.path = str(path)
        with sqlite3.connect(self.path) as db:
            db.execute(
                "CREATE TABLE IF NOT EXISTS accounts (id TEXT PRIMARY KEY, username TEXT UNIQUE NOT NULL, salt BLOB NOT NULL, digest BLOB NOT NULL)"
            )
            db.execute(
                "CREATE TABLE IF NOT EXISTS account_sessions (digest TEXT PRIMARY KEY, account_id TEXT NOT NULL, expires REAL NOT NULL)"
            )

    @staticmethod
    def password_hash(password, salt):
        if not isinstance(password, str) or not 8 <= len(password) <= 128:
            raise ValueError("密码长度须为 8–128 个字符")
        return hashlib.scrypt(password.encode(), salt=salt, n=16384, r=8, p=1)

    def register(self, username, password):
        if not isinstance(username, str) or not re.fullmatch(
            r"[a-zA-Z0-9_]{3,24}", username
        ):
            raise ValueError("账号使用 3–24 位英文字母、数字或下划线")
        username = username.lower()
        salt = secrets.token_bytes(16)
        digest = self.password_hash(password, salt)
        account = {"id": str(uuid4()), "username": username}
        try:
            with sqlite3.connect(self.path) as db:
                db.execute(
                    "INSERT INTO accounts VALUES (?, ?, ?, ?)",
                    (account["id"], username, salt, digest),
                )
        except sqlite3.IntegrityError as exc:
            raise ValueError("账号已存在") from exc
        return account

    def login(self, username, password):
        if not isinstance(username, str):
            raise TypeError("请输入账号")
        with sqlite3.connect(self.path) as db:
            row = db.execute(
                "SELECT id, username, salt, digest FROM accounts WHERE username=?",
                (username.lower(),),
            ).fetchone()
        digest = self.password_hash(password, row[2] if row else bytes(16))
        if not row or not hmac.compare_digest(digest, row[3]):
            raise PermissionError("账号或密码错误")
        return {"id": row[0], "username": row[1]}

    def issue(self, account):
        token = secrets.token_urlsafe(32)
        with sqlite3.connect(self.path) as db:
            db.execute("DELETE FROM account_sessions WHERE expires < ?", (time.time(),))
            db.execute(
                "INSERT INTO account_sessions VALUES (?, ?, ?)",
                (
                    hashlib.sha256(token.encode()).hexdigest(),
                    account["id"],
                    time.time() + 30 * 86400,
                ),
            )
        return token

    def identify(self, token):
        with sqlite3.connect(self.path) as db:
            row = db.execute(
                "SELECT a.id, a.username FROM account_sessions s JOIN accounts a ON a.id=s.account_id WHERE s.digest=? AND s.expires>?",
                (hashlib.sha256(token.encode()).hexdigest(), time.time()),
            ).fetchone()
        return {"id": row[0], "username": row[1]} if row else None

    def logout(self, token):
        with sqlite3.connect(self.path) as db:
            db.execute(
                "DELETE FROM account_sessions WHERE digest=?",
                (hashlib.sha256(token.encode()).hexdigest(),),
            )

    def history(self, history, account_id, hand_id=None):
        rows = []
        style_samples = []
        for hand in history.records():
            bid = next(
                (
                    bid
                    for bid, p in hand.get("participants", {}).items()
                    if p.get("account_id") == account_id
                ),
                None,
            )
            if bid is None or bid not in hand["chip_delta"]:
                continue
            style_samples.append((hand, bid))
            row = {
                "id": hand["id"],
                "session": hand["session"],
                "hand": hand["hand"],
                "finished_at": hand["finished_at"],
                "delta": hand["chip_delta"][bid],
                "board": hand["result"]["community_cards"],
                "cards": hand["hole_cards"][bid],
                "pot": hand["result"]["pot"],
            }
            if hand_id == hand["id"]:
                # Never expose full stored engine events or other players' observations.
                row.update(
                    replay=build_replay(hand, bid),
                    viewer=bid,
                    names={
                        p: v["name"] for p, v in hand.get("participants", {}).items()
                    },
                    revealed=hand["result"].get("revealed_cards", {}),
                    actions=hand["result"]["action_log"],
                    winners=hand["result"]["winners"],
                    starting_stack=hand["starting_stacks"][bid],
                    final_stack=hand["result"]["final_stacks"][bid],
                )
                return row
            rows.append(row)
        if hand_id is not None:
            raise PermissionError("无权查看该牌局或记录不存在")
        total = sum(r["delta"] for r in rows)
        return {
            "style_stats": summarize_style(style_samples),
            "hands": len(rows),
            "net_chips": total,
            "net_bb": total / 100,
            "bb100": total / len(rows) if rows else 0,
            "profitable_hands": sum(r["delta"] > 0 for r in rows),
            "records": rows,
        }
