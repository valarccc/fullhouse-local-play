"""LAN rooms: authenticated seats, server-owned turns, and isolated observations."""

from __future__ import annotations

import argparse
import copy
import json
import random
import secrets
import sys
import threading
import time
from functools import wraps
from http.cookies import SimpleCookie
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlsplit

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from local_play.accounts import Accounts
from local_play.history import History
from local_play.personalities import AVATARS, STYLES, choose_action
from local_play.server import Table, TableEngine
from local_play.style_stats import summarize_style


class LanTable(Table):
    def next_hand(self):
        # The host may be eliminated; remaining seats can still play.
        if self.save_error:
            self.persist_hand()
            if self.save_error:
                raise ValueError("牌谱写入失败，请检查服务器磁盘")
        if self.state and self.state["type"] != "hand_complete":
            raise ValueError("本手还未结束")
        alive = [bid for bid in self.ids if self.stacks[bid] > 0]
        if len(alive) < 2:
            raise ValueError("本桌已结束，请开始新牌桌")
        if self.hand:
            old = self.ids.index(self.dealer_id)
            self.dealer_id = next(
                self.ids[(old + i) % 6]
                for i in range(1, 7)
                if self.ids[(old + i) % 6] in alive
            )
        from datetime import datetime, timezone
        from uuid import uuid4

        self.hand += 1
        self.record_id = str(uuid4())
        self.started_at = datetime.now(timezone.utc).isoformat()
        self.decisions = []
        self.saved = False
        self.engine = TableEngine(
            str(self.hand), alive, alive.index(self.dealer_id), self.stacks
        )
        self.state = self.engine.start_hand()
        if self.state["type"] == "hand_complete":
            self.stacks.update(self.state["final_stacks"])
            self.persist_hand()
        self.revision += 1


class Room:
    def __init__(
        self,
        code,
        nickname,
        avatar,
        history=None,
        policy=choose_action,
        clock=time.monotonic,
        account_id=None,
    ):
        self.code, self.clock, self.policy = code, clock, policy
        self.table = LanTable(history=history)
        self.members = {}
        self.humans = {}
        self.phase = "lobby"
        self.version = 0
        self.due = None
        self.next_due = None
        self.auto_paused = False
        self.break_seconds = 15
        self.turn_seconds = 60
        self.ai_seconds = 1.8
        self.error = None
        self.rebuys = []
        self.host_token = self.join(nickname, avatar, account_id)
        self.last_used = clock()

    @staticmethod
    def validate_member(nickname, avatar):
        if not isinstance(nickname, str) or not 1 <= len(nickname.strip()) <= 16:
            raise ValueError("昵称需为 1–16 个字符")
        if avatar not in AVATARS:
            raise ValueError("请选择列表中的头像")

    def join(self, nickname, avatar, account_id=None):
        self.validate_member(nickname, avatar)
        if account_id:
            existing = next(
                (
                    bid
                    for bid, m in self.humans.items()
                    if m.get("account_id") == account_id
                ),
                None,
            )
            if existing:
                return next(
                    token for token, bid in self.members.items() if bid == existing
                )
        if self.phase != "lobby":
            raise ValueError("本桌已经开始，请等待房主返回大厅")
        free = next((bid for bid in self.table.ids if bid not in self.humans), None)
        if free is None:
            raise ValueError("房间已满")
        token = secrets.token_urlsafe(32)
        self.members[token] = free
        self.humans[free] = {
            "account_id": account_id,
            "name": nickname.strip(),
            "avatar": avatar,
            "last_seen": self.clock(),
        }
        self.version += 1
        return token

    def authenticate(self, token):
        if token not in self.members:
            raise PermissionError("座位凭据无效，请重新加入房间")
        bid = self.members[token]
        self.humans[bid]["last_seen"] = self.clock()
        self.last_used = self.clock()
        return bid

    def host_only(self, token):
        if token != self.host_token:
            raise PermissionError("只有房主可以操作")

    def start(self, token, config, revision):
        self.authenticate(token)
        self.host_only(token)
        self.check_revision(revision)
        if self.phase != "lobby":
            raise ValueError("请先返回大厅")
        self.table.participants = {
            bid: {
                "name": m["name"],
                "avatar": m["avatar"],
                "account_id": m.get("account_id"),
            }
            for bid, m in self.humans.items()
        }
        self.table.reset(config)
        self.rebuys = []
        self.phase = "playing"
        self.error = None
        self.version += 1
        self.schedule()

    def check_revision(self, revision):
        if type(revision) is not int or revision != self.version:
            raise ValueError("牌局已更新，请稍后重试")

    def schedule(self, extra=0):
        self.next_due = None
        if self.table.state["type"] == "hand_complete":
            self.auto_rebuy_ai()
            self.due = None
            if (
                not self.auto_paused
                and sum(v > 0 for v in self.table.stacks.values()) > 1
            ):
                self.next_due = self.clock() + self.break_seconds
        else:
            bid = self.table.engine.players[self.table.state["seat_to_act"]].bot_id
            delay = (
                self.turn_seconds
                if bid in self.humans
                else random.uniform(0.6, 1.4) * self.ai_seconds
            )
            self.due = self.clock() + extra + delay

    def apply(self, raw, source):
        t = self.table
        seat = t.state["seat_to_act"]
        bid = t.engine.players[seat].bot_id
        # Human requests and timeout defaults must pass strict UI validation.
        if bid in self.humans:
            t.validate_human(raw)
        observation = copy.deepcopy(t.state)
        old_board = len(t.engine.community_cards)
        t.state = t.engine.apply_action(seat, raw)
        t.decisions.append(
            {
                "player": bid,
                "source": source,
                "style": "human"
                if bid in self.humans
                else t.config[t.ids.index(bid) - 1]["style"],
                "observation": observation,
                "requested_action": copy.deepcopy(raw),
                "applied_action": copy.deepcopy(t.engine.action_log[-1]),
            }
        )
        if t.state["type"] == "hand_complete":
            t.stacks.update(t.state["final_stacks"])
            t.persist_hand()
        t.revision += 1
        self.version += 1
        self.schedule(extra=2.5 if len(t.engine.community_cards) > old_board else 0)

    def act(self, token, revision, raw):
        bid = self.authenticate(token)
        self.check_revision(revision)
        if self.phase != "playing" or self.table.state["type"] == "hand_complete":
            raise ValueError("当前不能行动")
        actor = self.table.engine.players[self.table.state["seat_to_act"]].bot_id
        if actor != bid:
            raise PermissionError("还没轮到你")
        self.apply(raw, "human")

    def tick(self):
        if self.phase == "playing" and self.table.state["type"] == "hand_complete":
            if (
                not self.auto_paused
                and not self.error
                and self.next_due is not None
                and self.clock() >= self.next_due
            ):
                try:
                    self.table.next_hand()
                    self.version += 1
                    self.schedule()
                except (ValueError, OSError) as exc:
                    self.error = str(exc)
                    self.next_due = None
                    self.version += 1
            return
        if (
            self.phase != "playing"
            or self.due is None
            or self.clock() < self.due
            or self.error
        ):
            return
        t = self.table
        bid = t.engine.players[t.state["seat_to_act"]].bot_id
        try:
            if bid in self.humans:
                self.apply(
                    {"action": "check" if t.state["can_check"] else "fold"},
                    "human_timeout",
                )
            else:
                self.apply(
                    self.policy(t.state, t.config[t.ids.index(bid) - 1]["style"]), "ai"
                )
        except Exception as exc:  # noqa: BLE001 -- pause this room instead of killing all rooms
            import traceback

            traceback.print_exc()
            self.error = "房间已暂停，请房主查看服务器日志：" + str(exc)
            self.version += 1

    def can_rebuy(self, bid):
        t = self.table
        if self.phase != "playing" or t.stacks[bid] != 0:
            return False
        # Zero chips committed in a live all-in are not an eliminated seat.
        return t.state["type"] == "hand_complete" or not any(
            p.bot_id == bid for p in t.engine.players
        )

    def credit_rebuy(self, bid, automatic=False):
        t = self.table
        if t.stacks[bid] != 0:
            return
        if t.save_error:
            t.persist_hand()
            if t.save_error:
                raise ValueError("请先处理牌谱保存错误")
        from datetime import datetime, timezone
        from uuid import uuid4

        record = {
            "id": str(uuid4()),
            "session": t.session,
            "after_hand": t.hand,
            "player": bid,
            "name": self.humans[bid]["name"]
            if bid in self.humans
            else f"AI {t.ids.index(bid)}",
            "automatic": automatic,
            "amount": 10000,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }
        if t.history:
            t.history.save_rebuy(record)
        t.stacks[bid] = 10000
        self.rebuys.append(record)
        self.version += 1

    def auto_rebuy_ai(self):
        if self.table.save_error:
            return
        for bid in self.table.ids:
            if bid not in self.humans and self.table.stacks[bid] == 0:
                self.credit_rebuy(bid, automatic=True)

    def rebuy(self, token, revision):
        bid = self.authenticate(token)
        self.check_revision(revision)
        if not self.can_rebuy(bid):
            raise ValueError("仅已出局且筹码归零的玩家可买入；全下须等待结算")
        self.credit_rebuy(bid)
        if (
            self.table.state["type"] == "hand_complete"
            and self.next_due is None
            and not self.auto_paused
        ):
            self.schedule()

    def set_break(self, token, revision, seconds):
        self.authenticate(token)
        self.host_only(token)
        self.check_revision(revision)
        if type(seconds) is not int or not 5 <= seconds <= 120:
            raise ValueError("自动续局间隔须为 5–120 秒的整数")
        self.break_seconds = seconds
        if self.next_due is not None and not self.auto_paused:
            self.next_due = self.clock() + seconds
        self.version += 1

    def set_speed(self, token, revision, seconds):
        self.authenticate(token)
        self.host_only(token)
        self.check_revision(revision)
        if type(seconds) not in (int, float) or seconds not in (1.0, 1.8, 3.0):
            raise ValueError("请选择快、标准或慢速")
        self.ai_seconds = float(seconds)
        # Existing turn deadlines stay intact; the next AI turn uses this setting.
        self.version += 1

    def set_pause(self, token, revision, paused):
        self.authenticate(token)
        self.host_only(token)
        self.check_revision(revision)
        if type(paused) is not bool:
            raise TypeError("暂停状态无效")
        self.auto_paused = paused
        self.next_due = None
        if self.phase == "playing" and self.table.state["type"] == "hand_complete":
            self.schedule()
        self.version += 1

    def next_hand(self, token, revision):
        self.authenticate(token)
        self.host_only(token)
        self.check_revision(revision)
        if self.phase != "playing":
            raise ValueError("请先开局")
        self.table.next_hand()
        self.version += 1
        self.schedule()

    def lobby(self, token, revision):
        self.authenticate(token)
        self.host_only(token)
        self.check_revision(revision)
        if self.phase == "playing" and self.table.state["type"] != "hand_complete":
            raise ValueError("本手结束后才能返回大厅")
        if self.table.save_error:
            self.table.persist_hand()
            if self.table.save_error:
                raise ValueError("请先处理牌谱保存错误")
        self.phase = "lobby"
        self.due = None
        self.next_due = None
        self.version += 1

    def finances(self):
        t = self.table
        key = (t.session, t.hand, t.saved)
        if getattr(self, '_style_cache_key', None) != key:
            records = [h for h in t.history.records() if h['session'] == t.session] if t.history else []
            self._style_cache = {bid: summarize_style((h, bid) for h in records) for bid in t.ids}
            self._style_cache_key = key
        live = self.phase == "playing" and t.state["type"] != "hand_complete"
        rows = []
        for i, bid in enumerate(t.ids):
            rebuys = [r for r in self.rebuys if r["player"] == bid]
            buyin = 10000 + sum(r["amount"] for r in rebuys)
            p = next((p for p in t.engine.players if p.bot_id == bid), None)
            rows.append(
                {
                    "id": bid,
                    "name": self.humans[bid]["name"]
                    if bid in self.humans
                    else f"AI {i}",
                    "kind": "真人" if bid in self.humans else "AI",
                    "style_stats": self._style_cache[bid],
                    "initial_buyin": 10000,
                    "rebuy_count": len(rebuys),
                    "rebuy_total": buyin - 10000,
                    "total_buyin": buyin,
                    "stack": p.stack if live and p else t.stacks[bid],
                    "in_pot": p.total_invested if live and p else 0,
                    "settled_chips": t.stacks[bid],
                    "profit": t.stacks[bid] - buyin,
                }
            )
        return {
            "session": t.session,
            "rows": rows,
            "rebuys": self.rebuys,
            "total_buyin": sum(r["total_buyin"] for r in rows),
            "total_profit": sum(r["profit"] for r in rows),
        }

    def view(self, token):
        viewer = self.authenticate(token)
        t = self.table
        playing = self.phase == "playing"
        done = playing and t.state["type"] == "hand_complete"
        actor = (
            t.engine.players[t.state["seat_to_act"]].bot_id
            if playing and not done
            else None
        )
        revealed = t.state.get("revealed_cards", {}) if done else {}
        players = []
        for i, bid in enumerate(t.ids):
            p = next((p for p in t.engine.players if p.bot_id == bid), None)
            member = self.humans.get(bid)
            config = t.config[i - 1] if i else {"style": "original", "avatar": "🤖"}
            players.append(
                {
                    "id": bid,
                    "human": bool(member),
                    "name": member["name"] if member else f"AI {i}",
                    "avatar": member["avatar"] if member else config["avatar"],
                    "style": "真人" if member else STYLES[config["style"]][0],
                    "online": bool(member and self.clock() - member["last_seen"] < 10),
                    "stack": p.stack
                    if playing and p
                    else (10000 if not playing else 0),
                    "bet": p.bet_this_street if playing and p else 0,
                    "status": p.state
                    if playing and p
                    else ("waiting" if not playing else "busted"),
                    "cards": (
                        [str(c) for c in p.hole_cards]
                        if bid == viewer and p
                        else revealed.get(bid, [])
                    )
                    if playing
                    else [],
                    "dealer": playing and bid == t.dealer_id,
                    "acting": bid == actor,
                }
            )
        for player in players:
            if playing and not any(p.bot_id == player["id"] for p in t.engine.players):
                player["stack"] = t.stacks[player["id"]]
                if player["stack"] > 0:
                    player["status"] = "rebought"
        if done:
            for player in players:
                player["stack"] = t.stacks[player["id"]]
                if any(
                    r["player"] == player["id"] and r["after_hand"] == t.hand
                    for r in self.rebuys
                ):
                    player["status"] = "rebought"
        legal = None
        if actor == viewer:
            legal = {
                k: t.state[k]
                for k in ("can_check", "can_raise", "amount_owed", "min_raise_to")
            }
            legal["max_raise_to"] = (
                t.state["your_stack"] + t.state["your_bet_this_street"]
            )
        events = (
            [
                {
                    "player": event["bot_id"],
                    "action": event["action"],
                    "amount": event["amount"],
                }
                for event in t.engine.events
                if event["type"] in ("blind", "action")
            ]
            if playing
            else []
        )
        return {
            "finances": self.finances(),
            "code": self.code,
            "viewer": viewer,
            "host": token == self.host_token,
            "phase": self.phase,
            "revision": self.version,
            "players": players,
            "legal": legal,
            "actor": actor,
            "done": done,
            "hand": t.hand if playing else 0,
            "street": t.engine.street if playing else "preflop",
            "board": [str(c) for c in t.engine.community_cards] if playing else [],
            "pot": t.engine.pot if playing else 0,
            "events": events,
            "winners": t.state.get("winners", []) if done else [],
            "runout_odds": getattr(t.engine, "runout_odds", {}) if done else {},
            "seconds_left": max(0, round(self.due - self.clock()))
            if self.due
            else None,
            "break_seconds": self.break_seconds,
            "ai_seconds": self.ai_seconds,
            "auto_paused": self.auto_paused,
            "next_in": max(0, round(self.next_due - self.clock()))
            if self.next_due is not None
            else None,
            "can_rebuy": self.can_rebuy(viewer),
            "rebuy_count": sum(r["player"] == viewer for r in self.rebuys),
            "rebuys": self.rebuys,
            "can_next": done and sum(v > 0 for v in t.stacks.values()) > 1,
            "config": t.config,
            "styles": {k: v[0] for k, v in STYLES.items()},
            "avatars": AVATARS,
            "error": self.error or t.save_error,
        }


def make_handler(rooms, history, accounts=None, lock=None):
    lock = lock or threading.RLock()

    def synchronized(method):
        @wraps(method)
        def wrapped(self, *args, **kwargs):
            with lock:
                return method(self, *args, **kwargs)

        return wrapped

    accounts = accounts or Accounts(history.path)
    auth_attempts = {}

    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *args):
            pass

        def send(
            self, status, body, mime="application/json; charset=utf-8", cookie=None
        ):
            data = (
                json.dumps(body, ensure_ascii=False).encode()
                if isinstance(body, dict)
                else body
            )
            self.send_response(status)
            self.send_header("Content-Type", mime)
            self.send_header("Content-Length", str(len(data)))
            self.send_header("Cache-Control", "no-store")
            if cookie is not None:
                self.send_header("Set-Cookie", cookie)
            self.send_header("X-Content-Type-Options", "nosniff")
            self.end_headers()
            try:
                self.wfile.write(data)
            except (BrokenPipeError, ConnectionResetError):
                pass

        def account_token(self):
            cookie = SimpleCookie()
            try:
                cookie.load(self.headers.get("Cookie", ""))
                return (
                    cookie["riverside_account"].value
                    if "riverside_account" in cookie
                    else ""
                )
            except Exception:  # noqa: BLE001 -- malformed client cookie is unauthenticated
                return ""

        def account(self, required=False):
            account = accounts.identify(self.account_token())
            if required and not account:
                raise PermissionError("请先登录账号")
            return account

        def get_room(self):
            code = self.headers.get("X-Room-Code", "").upper()
            room = rooms.get(code)
            if room is None:
                raise ValueError("房间不存在，服务器重启后需要重新建房")
            token = self.headers.get("X-Seat-Token", "")
            bid = room.members.get(token)
            owner = room.humans.get(bid, {}).get("account_id")
            if owner and self.account(required=True)["id"] != owner:
                raise PermissionError("请登录该座位绑定的账号")
            return room, token

        @synchronized
        def do_GET(self):
            if urlsplit(self.path).path == "/":
                return self.send(
                    200,
                    (ROOT / "local_play/static/lan.html").read_bytes(),
                    "text/html; charset=utf-8",
                )
            if urlsplit(self.path).path == '/replay':
                return self.send(200, (ROOT/'local_play/static/replay.html').read_bytes(), 'text/html; charset=utf-8')
            if self.path == "/account":
                return self.send(
                    200,
                    (ROOT / "local_play/static/account.html").read_bytes(),
                    "text/html; charset=utf-8",
                )
            try:
                if self.path == "/api/account":
                    return self.send(200, {"account": self.account()})
                if self.path == "/api/account/history":
                    return self.send(
                        200,
                        accounts.history(history, self.account(required=True)["id"]),
                    )
                if self.path.startswith("/api/account/hand/"):
                    return self.send(
                        200,
                        accounts.history(
                            history,
                            self.account(required=True)["id"],
                            self.path.rsplit("/", 1)[-1],
                        ),
                    )
                if self.path == "/api/room":
                    room, token = self.get_room()
                    return self.send(200, room.view(token))
                self.send(404, {"error": "Not found"})
            except PermissionError as exc:
                self.send(403, {"error": str(exc)})
            except ValueError as exc:
                self.send(400, {"error": str(exc)})

        @synchronized
        def do_POST(self):
            try:
                origin = self.headers.get("Origin")
                if origin and urlsplit(origin).netloc != self.headers.get("Host"):
                    raise PermissionError("不允许跨站请求")
                if (
                    self.headers.get("Content-Type", "").split(";")[0]
                    != "application/json"
                ):
                    raise ValueError("请求必须为 JSON")
                length = int(self.headers.get("Content-Length", "0"))
                if not 0 < length <= 8192:
                    raise ValueError("请求大小无效")
                body = json.loads(self.rfile.read(length))
                if not isinstance(body, dict):
                    raise TypeError("请求格式无效")
                if self.path in ("/api/register", "/api/login"):
                    ip = self.client_address[0]
                    attempts = [
                        t
                        for t in auth_attempts.get(ip, [])
                        if time.monotonic() - t < 60
                    ]
                    if len(attempts) >= 15:
                        raise ValueError("尝试过于频繁，请一分钟后重试")
                    attempts.append(time.monotonic())
                    auth_attempts[ip] = attempts
                    account = (
                        accounts.register
                        if self.path == "/api/register"
                        else accounts.login
                    )(body.get("username"), body.get("password"))
                    accounts.logout(self.account_token())
                    token = accounts.issue(account)
                    return self.send(
                        200,
                        {"account": account},
                        cookie=f"riverside_account={token}; HttpOnly; SameSite=Strict; Path=/; Max-Age=2592000",
                    )
                if self.path == "/api/logout":
                    accounts.logout(self.account_token())
                    return self.send(
                        200,
                        {"ok": True},
                        cookie="riverside_account=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0",
                    )
                if self.path == "/api/create":
                    if len(rooms) >= 20:
                        raise ValueError("房间数量已达上限，请重启服务清理空闲房间")
                    code = "".join(
                        secrets.choice("ABCDEFGHJKLMNPQRSTUVWXYZ23456789")
                        for _ in range(6)
                    )
                    while code in rooms:
                        code = secrets.token_hex(3).upper()
                    room = Room(
                        code,
                        body.get("name"),
                        body.get("avatar"),
                        history,
                        account_id=(self.account() or {}).get("id"),
                    )
                    rooms[code] = room
                    return self.send(
                        200,
                        {"token": room.host_token, "room": room.view(room.host_token)},
                    )
                if self.path == "/api/join":
                    code = body.get("code")
                    if not isinstance(code, str) or code.upper() not in rooms:
                        raise ValueError("房间码无效")
                    room = rooms[code.upper()]
                    token = room.join(
                        body.get("name"),
                        body.get("avatar"),
                        (self.account() or {}).get("id"),
                    )
                    return self.send(200, {"token": token, "room": room.view(token)})
                room, token = self.get_room()
                room.authenticate(token)
                revision = body.get("revision")
                if self.path == "/api/start":
                    config = body.get("config")
                    if not isinstance(config, list):
                        raise ValueError("缺少 AI 配置")
                    room.start(token, config, revision)
                elif self.path == "/api/action":
                    room.act(token, revision, body.get("action"))
                elif self.path == "/api/rebuy":
                    room.rebuy(token, revision)
                elif self.path == "/api/break":
                    room.set_break(token, revision, body.get("seconds"))
                elif self.path == "/api/speed":
                    room.set_speed(token, revision, body.get("seconds"))
                elif self.path == "/api/pause":
                    room.set_pause(token, revision, body.get("paused"))
                elif self.path == "/api/next":
                    room.next_hand(token, revision)
                elif self.path == "/api/lobby":
                    room.lobby(token, revision)
                else:
                    return self.send(404, {"error": "Not found"})
                self.send(200, room.view(token))
            except PermissionError as exc:
                self.send(403, {"error": str(exc)})
            except (ValueError, TypeError) as exc:
                self.send(400, {"error": str(exc)})
            except Exception:  # noqa: BLE001 -- report failure, keep other rooms running
                import traceback

                traceback.print_exc()
                self.send(500, {"error": "服务器错误，请查看终端日志"})

    return Handler


class LanHTTPServer(ThreadingHTTPServer):
    def get_request(self):
        connection, address = super().get_request()
        connection.settimeout(5)
        return connection, address


def main():
    parser = argparse.ArgumentParser(description="河岸局域网多人扑克")
    parser.add_argument("--host", default="0.0.0.0")
    parser.add_argument("--port", type=int, default=5051)
    args = parser.parse_args()
    rooms = {}
    history = History(ROOT / "local_play/records/lan_history.sqlite3")
    lock = threading.RLock()
    server = LanHTTPServer(
        (args.host, args.port), make_handler(rooms, history, lock=lock)
    )
    server.timeout = 0.1
    print(
        f"局域网牌桌已启动：http://localhost:{args.port}\n朋友访问 http://你的局域网IP:{args.port} ，输入房间码加入。Ctrl+C 退出。",
        flush=True,
    )
    try:
        while True:
            server.handle_request()
            with lock:
                for room in list(rooms.values()):
                    room.tick()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
