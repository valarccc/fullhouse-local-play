"""Bounded, state-dependent style biases; no training or weight changes."""

import numpy as np

from bot import bot as runtime

STYLES = {
    "original": ("原版", 0.0, 0.0),
    "tag": ("紧凶", 0.65, 0.65),
    "lag": ("松凶", -0.65, 0.8),
    "tight_passive": ("紧被动", 0.7, -0.7),
    "loose_passive": ("松被动", -0.7, -0.8),
}
AVATARS = ["🦊", "🐺", "🐼", "🦉", "🦁", "🐯", "🐸", "🤖"]


def adjust_strategy(probs, state, style):
    _, tight, aggression = STYLES[style]
    p = np.asarray(probs, dtype=float).copy()
    if style == "original":
        return p
    owed = max(0, state.get("amount_owed", 0))
    pressure = min(1.0, owed / max(1, state.get("pot", 0) + owed))
    # Preserve the model's assessment: only reweight actions it already supports.
    commitment = min(1.0, owed / max(1, state.get("your_stack", 1)))
    strength_proxy = float(p[2:].sum())
    bias = np.zeros(5)
    if state.get("street") == "preflop":
        bias[0] = tight * (1.0 - 0.5 * strength_proxy)
        bias[1] = -0.35 * tight - 0.35 * aggression
    else:
        bias[0] = tight * pressure
        bias[1] = -0.45 * aggression
    bias[2:4] = aggression * (0.65 - 0.3 * commitment)
    bias[0] += -0.25 * aggression * pressure
    bias[4] = 0.15 * aggression * (1.0 - commitment)
    p *= np.exp(np.clip(bias, -0.8, 0.8))
    return p / p.sum()


def choose_action(state, style):
    if style == "original":
        return runtime.decide(state)
    if state.get("street") == "preflop":
        short = runtime._push_fold(state)
        if short is not None:
            return short
    probs = runtime._apply_legal_mask(runtime._DEEP_CFR.get_strategy(state), state)
    probs = adjust_strategy(probs, state, style)
    probs = runtime._apply_legal_mask(probs, state)
    return runtime._to_engine_action(runtime._sample(probs), state)
