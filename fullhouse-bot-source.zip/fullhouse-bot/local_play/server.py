"""Local, single-table human versus Deep CFR application (stdlib HTTP server)."""

from __future__ import annotations

import argparse
import copy
import hashlib
import json
import secrets
import sqlite3
import sys
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from uuid import uuid4

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from bot.bot import decide
from engine_vendored.engine.game import Action, PokerEngine


class TableEngine(PokerEngine):
    """Keep upstream untouched; enforce action reopening and turn ownership here."""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.acted_at = {}
        self.pending = None

    def start_hand(self):
        state = super().start_hand()
        active = [p for p in self.players if p.is_active]
        if not active or (
            len(active) == 1 and active[0].bet_this_street >= self.current_bet
        ):
            self.pending = None
            return self._run_it_out()
        return state

    def can_raise(self, seat):
        return (
            seat not in self.acted_at
            or self.current_bet - self.acted_at[seat] >= self.min_raise
        )

    def _build_state(self, seat):
        self.pending = seat
        state = super()._build_state(seat)
        state.update(dealer=self.dealer_seat, can_raise=self.can_raise(seat))
        return state

    def apply_action(self, seat, raw):
        if seat != self.pending:
            raise ValueError("还没轮到这个座位行动")
        self.pending = None
        return super().apply_action(seat, raw)

    def _emit_action(self, seat, action, amount):
        self.acted_at[seat] = self.current_bet
        super()._emit_action(seat, action, amount)

    def _validate(self, seat, raw):
        action = super()._validate(seat, raw)
        p = self.players[seat]
        raises = action.action == "raise" or (
            action.action == "all_in" and p.stack + p.bet_this_street > self.current_bet
        )
        if raises and not self.can_raise(seat):
            return Action(
                seat, "call" if self.current_bet > p.bet_this_street else "check"
            )
        return action

    def _handle_aggression(self, seat, raise_size):
        super()._handle_aggression(seat, raise_size)
        # A short all-in still requires undercalled players to respond.
        self._needs_to_act.update(
            p.seat
            for p in self.players
            if p.is_active and p.bet_this_street < self.current_bet
        )

    def _run_it_out(self):
        visible = [str(c) for c in self.community_cards]
        hands = {
            p.bot_id: [str(c) for c in p.hole_cards]
            for p in self.players
            if not p.is_folded
        }
        result = super()._run_it_out()
        if len(hands) >= 2:
            board = result["community_cards"]
            self.runout_odds = {
                str(n): showdown_odds(hands, board[:n])
                for n in (0, 3, 4, 5)
                if n >= len(visible)
            }
        return result

    def _advance_street(self):
        self.acted_at.clear()
        # No further betting when only one player has chips left.
        if sum(p.is_active for p in self.players) <= 1:
            return self._run_it_out()
        return super()._advance_street()


from local_play.equity import showdown_odds
from local_play.history import History
from local_play.personalities import AVATARS, STYLES, choose_action


class Table:
    def __init__(self, policy=decide, require_setup=False, history=None):
        self.history = history
        self.save_error = None
        self.model_hash = hashlib.sha256(
            (ROOT / "data/deep_cfr_model.npz").read_bytes()
        ).hexdigest()
        self.policy = policy
        self.revision = 0
        self.config = [
            {"style": style, "avatar": AVATARS[i]} for i, style in enumerate(STYLES)
        ]
        self.reset()
        self.configured = not require_setup

    def reset(self, config=None):
        if self.save_error:
            self.persist_hand()
            if self.save_error:
                raise ValueError("历史记录写入失败，请检查磁盘后重试")
        if config is not None:
            if not isinstance(config, list) or len(config) != 5:
                raise ValueError("请选择五位 AI")
            if any(
                not isinstance(c, dict)
                or c.get("style") not in STYLES
                or c.get("avatar") not in AVATARS
                for c in config
            ):
                raise ValueError("角色或头像无效")
            self.config = [{"style": c["style"], "avatar": c["avatar"]} for c in config]
        self.session = str(uuid4())
        self.configured = True
        self.ids = ["you", "ai1", "ai2", "ai3", "ai4", "ai5"]
        self.stacks = dict.fromkeys(self.ids, 10000)
        self.hand = 0
        self.dealer_id = "you"
        self.engine = None
        self.state = None
        self.next_hand()

    def next_hand(self):
        if self.save_error:
            self.persist_hand()
            if self.save_error:
                raise ValueError("历史记录写入失败，请检查磁盘后重试")
        if self.state and self.state["type"] != "hand_complete":
            raise ValueError("当前这手牌还没有结束")
        if self.stacks["you"] <= 0:
            raise ValueError("你的筹码已用完，请重开牌桌")
        alive = [bid for bid in self.ids if self.stacks[bid] > 0]
        if len(alive) < 2:
            raise ValueError("你已赢得牌桌，请重开牌桌")
        if self.hand:
            old = self.ids.index(self.dealer_id)
            self.dealer_id = next(
                self.ids[(old + i) % 6]
                for i in range(1, 7)
                if self.ids[(old + i) % 6] in alive
            )
        self.hand += 1
        self.record_id = str(uuid4())
        self.started_at = datetime.now(timezone.utc).isoformat()
        self.decisions = []
        self.saved = False
        self.engine = TableEngine(
            str(self.hand), alive, alive.index(self.dealer_id), self.stacks
        )
        self.state = self.engine.start_hand()
        if self.state["type"] == "hand_complete":
            self.persist_hand()
        self.revision += 1

    def step(self, raw=None):
        if not self.configured:
            raise ValueError("请先选择对手并开局")
        if self.state["type"] == "hand_complete":
            raise ValueError("这手牌已经结束")
        seat = self.state["seat_to_act"]
        human = self.engine.players[seat].bot_id == "you"
        if human:
            self.validate_human(raw)
        elif raw is not None:
            raise ValueError("请等待对手行动")
        else:
            bid = self.engine.players[seat].bot_id
            style = self.config[self.ids.index(bid) - 1]["style"]
            raw = (
                choose_action(self.state, style)
                if self.policy is decide
                else self.policy(self.state)
            )
        observation = copy.deepcopy(self.state)
        submitted = copy.deepcopy(raw)
        self.state = self.engine.apply_action(seat, raw)
        bid = self.engine.players[seat].bot_id
        self.decisions.append(
            {
                "player": bid,
                "source": "human" if human else "ai",
                "style": "human"
                if human
                else self.config[self.ids.index(bid) - 1]["style"],
                "observation": observation,
                "requested_action": submitted,
                "applied_action": copy.deepcopy(self.engine.action_log[-1]),
            }
        )
        if self.state["type"] == "hand_complete":
            self.stacks.update(self.state["final_stacks"])
            self.persist_hand()
        self.revision += 1

    def persist_hand(self):
        if not self.history or self.saved or self.state["type"] != "hand_complete":
            return
        e = self.engine
        initial = e._starting_stacks
        record = {
            "schema_version": 1,
            "participants": getattr(self, "participants", {}),
            "id": self.record_id,
            "session": self.session,
            "hand": self.hand,
            "started_at": self.started_at,
            "finished_at": datetime.now(timezone.utc).isoformat(),
            "model_sha256": self.model_hash,
            "config": copy.deepcopy(self.config),
            "blinds": {"small": 50, "big": 100},
            "dealer": self.dealer_id,
            "seats": [p.bot_id for p in e.players],
            "starting_stacks": initial,
            "hole_cards": {p.bot_id: [str(c) for c in p.hole_cards] for p in e.players},
            "chip_delta": {p.bot_id: p.stack - initial[p.bot_id] for p in e.players},
            "decisions": self.decisions,
            "result": self.state,
        }
        try:
            self.history.save(record)
            self.saved = True
            self.save_error = None
        except (OSError, sqlite3.Error) as exc:
            self.save_error = str(exc)

    def validate_human(self, raw):
        if not isinstance(raw, dict):
            raise TypeError("请选择操作")
        action = raw.get("action")
        s = self.state
        if action not in {"fold", "check", "call", "raise", "all_in"}:
            raise ValueError("未知操作")
        if action == "check" and not s["can_check"]:
            raise ValueError("需要跟注，不能过牌")
        cap = s["your_stack"] + s["your_bet_this_street"]
        if action == "raise":
            amount = raw.get("amount")
            if type(amount) is not int or not s["min_raise_to"] <= amount <= cap:
                raise ValueError("加注金额不在合法范围内")
        if (
            action == "raise" or action == "all_in" and cap > s["current_bet"]
        ) and not s["can_raise"]:
            raise ValueError("本轮加注权尚未重新开放，只能跟注或弃牌")

    def view(self):
        e, s = self.engine, self.state
        done = s["type"] == "hand_complete"
        actor = None if done else e.players[s["seat_to_act"]].bot_id
        revealed = s.get("revealed_cards", {})
        players = []
        for bid in self.ids:
            p = next((p for p in e.players if p.bot_id == bid), None)
            players.append(
                {
                    "id": bid,
                    "name": "你" if bid == "you" else f"AI {bid[-1]}",
                    "avatar": "🙂"
                    if bid == "you"
                    else self.config[self.ids.index(bid) - 1]["avatar"],
                    "style_label": "玩家"
                    if bid == "you"
                    else STYLES[self.config[self.ids.index(bid) - 1]["style"]][0],
                    "stack": p.stack if p else 0,
                    "bet": p.bet_this_street if p else 0,
                    "status": p.state if p else "busted",
                    "dealer": bid == self.dealer_id,
                    "cards": [str(c) for c in p.hole_cards]
                    if bid == "you" and p
                    else revealed.get(bid, []),
                    "acting": bid == actor,
                    "folded_cards": [str(c) for c in p.hole_cards]
                    if done and p and p.is_folded and bid != "you"
                    else [],
                }
            )
        legal = None
        if actor == "you":
            legal = {
                k: s[k]
                for k in ("can_check", "can_raise", "amount_owed", "min_raise_to")
            }
            legal["max_raise_to"] = s["your_stack"] + s["your_bet_this_street"]
        events = []
        for event in e.events:
            if event["type"] in ("blind", "action"):
                events.append(
                    {
                        "player": event["bot_id"],
                        "action": event["action"],
                        "amount": event["amount"],
                    }
                )
        return {
            "history_error": self.save_error,
            "configured": self.configured,
            "config": self.config,
            "styles": {key: value[0] for key, value in STYLES.items()},
            "avatars": AVATARS,
            "revision": self.revision,
            "hand": self.hand,
            "street": e.street,
            "pot": e.pot,
            "board": [str(c) for c in e.community_cards],
            "players": players,
            "actor": actor,
            "done": done,
            "legal": legal,
            "events": events,
            "winners": s.get("winners", []),
            "strengths": s.get("hand_strengths", {}),
            "runout_odds": getattr(e, "runout_odds", {}),
            "can_next": done
            and self.stacks["you"] > 0
            and sum(v > 0 for v in self.stacks.values()) > 1,
        }


def make_handler(table, token):
    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *args):
            pass

        def send(self, status, body, mime="application/json; charset=utf-8"):
            data = (
                json.dumps(body, ensure_ascii=False).encode()
                if isinstance(body, dict)
                else body
            )
            self.send_response(status)
            self.send_header("Content-Type", mime)
            self.send_header("Content-Length", str(len(data)))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(data)

        def do_GET(self):
            if self.path == "/api/state":
                self.send(200, {**table.view(), "token": token})
            elif self.path == "/api/history":
                self.send(200, table.history.summary())
            elif self.path.startswith("/api/hand/"):
                record = next(
                    (
                        r
                        for r in table.history.records()
                        if r["id"] == self.path.rsplit("/", 1)[-1]
                    ),
                    None,
                )
                self.send(200 if record else 404, record or {"error": "记录不存在"})
            elif self.path in ("/export/hands.jsonl", "/export/decisions.jsonl"):
                self.send(
                    200,
                    table.history.export(self.path.endswith("decisions.jsonl")),
                    "application/x-ndjson; charset=utf-8",
                )
            elif self.path == "/history":
                self.send(
                    200,
                    (Path(__file__).parent / "static/history.html").read_bytes(),
                    "text/html; charset=utf-8",
                )
            elif self.path == "/":
                self.send(
                    200,
                    (Path(__file__).parent / "static/index.html").read_bytes(),
                    "text/html; charset=utf-8",
                )
            else:
                self.send(404, {"error": "Not found"})

        def do_POST(self):
            if self.headers.get("X-Table-Token") != token:
                return self.send(403, {"error": "请刷新牌桌页面"})
            try:
                length = int(self.headers.get("Content-Length", "0"))
                if not 0 < length <= 4096:
                    raise ValueError("请求大小不正确")
                body = json.loads(self.rfile.read(length))
                if not isinstance(body, dict) or body.get("revision") != table.revision:
                    return self.send(409, {"error": "牌局状态已更新，请重试"})
                if self.path == "/api/action":
                    table.step(body.get("action"))
                elif self.path == "/api/next":
                    table.next_hand()
                elif self.path == "/api/reset":
                    table.reset(body.get("config"))
                else:
                    return self.send(404, {"error": "Not found"})
                self.send(200, table.view())
            except (ValueError, TypeError) as exc:
                self.send(400, {"error": str(exc)})
            except Exception:  # noqa: BLE001 -- preserve server availability and log traceback
                import traceback

                traceback.print_exc()
                self.send(500, {"error": "对局运行失败，请查看终端日志"})

    return Handler


def main():
    parser = argparse.ArgumentParser(description="本地六人德州牌桌")
    parser.add_argument("--port", type=int, default=5000)
    args = parser.parse_args()
    server = HTTPServer(
        ("127.0.0.1", args.port),
        make_handler(
            Table(
                require_setup=True,
                history=History(ROOT / "local_play/records/history.sqlite3"),
            ),
            secrets.token_urlsafe(32),
        ),
    )
    print(f"牌桌已启动：http://localhost:{args.port}  ·  Ctrl+C 退出", flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
