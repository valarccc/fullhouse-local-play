"""Showdown odds conditional on exposed hands and currently visible board."""

import itertools
import random

import eval7


def showdown_odds(hands, board, samples=4000, seed=42):
    known = [card for cards in hands.values() for card in cards] + list(board)
    if len(set(known)) != len(known) or not 0 <= len(board) <= 5 or len(hands) < 2:
        raise ValueError("Invalid showdown cards")
    deck = [r + s for r in "23456789TJQKA" for s in "shdc" if r + s not in known]
    missing = 5 - len(board)
    # Enumerate turn/river and flop exactly; preflop uses independent samples.
    exact = missing <= 2
    rng = random.Random(seed)
    runouts = (
        itertools.combinations(deck, missing)
        if exact
        else (rng.sample(deck, missing) for _ in range(samples))
    )
    holes = {bid: [eval7.Card(c) for c in cards] for bid, cards in hands.items()}
    base = [eval7.Card(c) for c in board]
    wins = dict.fromkeys(hands, 0)
    ties = dict.fromkeys(hands, 0)
    share = dict.fromkeys(hands, 0.0)
    count = 0
    for runout in runouts:
        public = base + [eval7.Card(c) for c in runout]
        scores = {bid: eval7.evaluate(cards + public) for bid, cards in holes.items()}
        best = max(scores.values())
        winners = [bid for bid, score in scores.items() if score == best]
        for bid in winners:
            if len(winners) == 1:
                wins[bid] += 1
            else:
                ties[bid] += 1
            share[bid] += 1 / len(winners)
        count += 1
    return {
        "board": list(board),
        "exact": exact,
        "samples": count,
        "players": [
            {
                "id": bid,
                "win": wins[bid] / count,
                "tie": ties[bid] / count,
                "equity": share[bid] / count,
            }
            for bid in hands
        ],
    }
