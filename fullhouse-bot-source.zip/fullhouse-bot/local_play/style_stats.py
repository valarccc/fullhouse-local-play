"""Descriptive playing statistics, independent of configured AI personalities."""


def summarize_style(samples):
    counts = {
        k: 0
        for k in (
            "hands",
            "vpip",
            "pfr",
            "three_bet",
            "three_bet_opportunities",
            "post_aggressive",
            "post_decisions",
            "facing_fold",
            "facing_bet",
            "timeout_hands",
            "label_hands",
            "label_vpip",
            "label_pfr",
        )
    }
    for hand, bid in samples:
        if bid not in hand.get("seats", []):
            continue
        decisions = hand.get("decisions", [])
        mine = [d for d in decisions if d["player"] == bid]
        if any(d.get("source") == "human_timeout" for d in mine):
            counts["timeout_hands"] += 1
            continue
        counts["hands"] += 1
        bb = hand.get("blinds", {}).get("big", 100)
        raised = entered = opportunity = threebet = False
        raises = 0
        for d in decisions:
            obs, action = d["observation"], d["applied_action"]
            act = action["action"]
            pre = obs["street"] == "preflop"
            current = obs.get("current_bet", 0)
            cap = obs.get("your_stack", 0) + obs.get("your_bet_this_street", 0)
            target = action.get("amount", 0) if act == "raise" else cap
            aggressive = act == "raise" or act == "all_in" and target > current
            full_raise = aggressive and target >= obs.get("min_raise_to", current + bb)
            if d["player"] == bid:
                if pre:
                    entered |= (
                        aggressive
                        or act in ("call", "all_in")
                        and obs.get("amount_owed", 0) > 0
                    )
                    raised |= aggressive
                    if (
                        raises == 1
                        and obs.get("can_raise", True)
                        and cap >= obs.get("min_raise_to", current + bb)
                    ):
                        opportunity = True
                        threebet |= full_raise
                else:
                    counts["post_decisions"] += 1
                    counts["post_aggressive"] += int(aggressive)
                if obs.get("amount_owed", 0) > 0:
                    counts["facing_bet"] += 1
                    counts["facing_fold"] += int(act == "fold")
            if pre and full_raise:
                raises += 1
        counts["vpip"] += int(entered)
        counts["pfr"] += int(raised)
        counts["three_bet_opportunities"] += int(opportunity)
        counts["three_bet"] += int(threebet)
        # Style labels use only 4–6 handed play with at least 25 BB starting chips.
        if 4 <= len(hand["seats"]) <= 6 and hand["starting_stacks"][bid] >= 25 * bb:
            counts["label_hands"] += 1
            counts["label_vpip"] += int(entered)
            counts["label_pfr"] += int(raised)

    def metric(numerator, denominator):
        n, d = counts[numerator], counts[denominator]
        return {
            "count": n,
            "opportunities": d,
            "percent": round(100 * n / d, 1) if d else None,
        }

    label = "样本不足"
    if counts["label_hands"] >= 50:
        vpip = counts["label_vpip"] / counts["label_hands"]
        ratio = counts["label_pfr"] / max(1, counts["label_vpip"])
        tightness = "偏紧" if vpip <= 0.22 else "偏松" if vpip >= 0.30 else "入池适中"
        aggression = (
            "偏主动" if ratio >= 0.6 else "偏被动" if ratio <= 0.35 else "主动性适中"
        )
        label = tightness + " · " + aggression
    return {
        "hands": counts["hands"],
        "excluded_timeout_hands": counts["timeout_hands"],
        "label_hands": counts["label_hands"],
        "label": label,
        "vpip": metric("vpip", "hands"),
        "pfr": metric("pfr", "hands"),
        "three_bet": metric("three_bet", "three_bet_opportunities"),
        "post_aggression": metric("post_aggressive", "post_decisions"),
        "fold_to_bet": metric("facing_fold", "facing_bet"),
    }
