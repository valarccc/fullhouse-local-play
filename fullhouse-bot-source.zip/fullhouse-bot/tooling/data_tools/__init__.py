"""Data generation helpers."""
