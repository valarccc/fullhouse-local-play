"""Training watcher package."""
