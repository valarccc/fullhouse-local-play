from local_play.style_stats import summarize_style


def decision(player, action, current=100, target=0, owed=100, street='preflop', minimum=200, source='ai'):
    return {'player': player, 'source': source,
            'observation': {'street': street, 'current_bet': current, 'amount_owed': owed,
                            'your_stack':10000, 'your_bet_this_street':0,
                            'min_raise_to':minimum, 'can_raise':True},
            'applied_action': {'action':action, 'amount':target}}


def hand(decisions):
    return {'seats':['a','b','c','d'], 'starting_stacks':dict.fromkeys('abcd',10000),
            'blinds':{'big':100}, 'decisions':decisions}


def test_opportunity_denominators_and_free_check():
    h = hand([decision('a','raise',target=300),
              decision('b','raise',current=300,target=900,minimum=500),
              decision('c','fold',current=900,minimum=1500)])
    s = summarize_style([(h,'b')])
    assert s['vpip']['count'] == s['pfr']['count'] == 1
    assert s['three_bet']['count'] == s['three_bet']['opportunities'] == 1
    assert summarize_style([(h,'c')])['three_bet']['opportunities'] == 0
    check = summarize_style([(hand([decision('a','check',owed=0)]),'a')])
    assert check['vpip']['count'] == check['pfr']['count'] == 0
    assert check['fold_to_bet']['opportunities'] == 0


def test_timeout_filter_and_style_threshold():
    h = hand([decision('a','fold',source='human_timeout')])
    stats = summarize_style([(h,'a')])
    assert stats['hands'] == 0 and stats['excluded_timeout_hands'] == 1
    h = hand([decision('a','call'),decision('a','check',owed=0,street='flop')])
    stats = summarize_style([(h,'a')]*50)
    assert stats['label'] == '偏松 · 偏被动'
    assert stats['post_aggression']['opportunities'] == 50
    assert summarize_style([(h,'a')]*49)['label'] == '样本不足'
    h['starting_stacks']['a'] = 1000
    assert summarize_style([(h,'a')]*50)['label'] == '样本不足'
