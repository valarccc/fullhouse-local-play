"""Persistent identity, privacy and cross-room attribution."""

import sqlite3
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from local_play.accounts import Accounts
from local_play.history import History
from local_play.lan_server import Room


def test_password_and_sessions(tmp_path):
    path = tmp_path / "history.sqlite3"
    History(path)
    accounts = Accounts(path)
    user = accounts.register("Alice", "test-password-123")
    assert accounts.login("ALICE", "test-password-123") == user
    with pytest.raises(PermissionError):
        accounts.login("alice", "wrong-password")
    with pytest.raises(ValueError):
        accounts.register("alice", "test-password-123")
    token = accounts.issue(user)
    assert Accounts(path).identify(token) == user
    with sqlite3.connect(path) as db:
        row = db.execute("SELECT digest FROM accounts").fetchone()
        assert row[0] != b"test-password-123"
    accounts.logout(token)
    assert accounts.identify(token) is None


def test_attribution_reconnect_and_private_history(tmp_path):
    path = tmp_path / "history.sqlite3"
    history = History(path)
    accounts = Accounts(path)
    alice = accounts.register("alice", "test-password-123")
    bob = accounts.register("bob", "test-password-123")
    for code in ["ROOM01", "ROOM02"]:
        room = Room(
            code,
            "Alice",
            "🦊",
            history,
            policy=lambda s, style: {"action": "call"},
            account_id=alice["id"],
        )
        room.join("Bob", "🐼", bob["id"])
        room.start(room.host_token, room.table.config, room.version)
        assert room.join("Alice", "🦊", alice["id"]) == room.host_token
        while room.table.state["type"] != "hand_complete":
            room.apply({"action": "fold"}, "human")
    stats = accounts.history(history, alice["id"])
    assert stats["hands"] == 2
    assert stats["net_chips"] == sum(h["chip_delta"]["you"] for h in history.records())
    hand_id = stats["records"][0]["id"]
    detail = accounts.history(history, alice["id"], hand_id)
    assert "hole_cards" not in detail and "decisions" not in detail
    assert detail["revealed"] == {}  # everyone folded; no opponents revealed
    assert len(detail["cards"]) == 2
    outsider = accounts.register("outsider", "test-password-123")
    assert accounts.history(history, outsider["id"])["hands"] == 0
    with pytest.raises(PermissionError):
        accounts.history(history, outsider["id"], hand_id)
