"""Multiplayer authorization, privacy, server scheduling and persistence."""

import json
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from local_play.history import History
from local_play.lan_server import Room


@pytest.fixture
def room(tmp_path):
    now = [100.0]
    room = Room(
        "ABCDEF",
        "Host",
        "🦊",
        History(tmp_path / "history.sqlite3"),
        policy=lambda s, style: {"action": "call"},
        clock=lambda: now[0],
    )
    room.test_clock = now
    return room


def test_separate_seats_and_hidden_cards(room):
    guest = room.join("Friend", "🐼")
    host = room.host_token
    with pytest.raises(PermissionError):
        room.start(guest, room.table.config, room.version)
    room.start(host, room.table.config, room.version)
    for token in [host, guest]:
        view = room.view(token)
        assert (
            len(next(p for p in view["players"] if p["id"] == view["viewer"])["cards"])
            == 2
        )
        assert all(not p["cards"] for p in view["players"] if p["id"] != view["viewer"])
        assert "folded_cards" not in json.dumps(view)
    with pytest.raises(PermissionError):
        room.view("invalid-token")
    with pytest.raises(ValueError):
        room.join("Late", "🐺")
    with pytest.raises(PermissionError):
        room.act(guest, room.version, {"action": "all_in"})


def test_server_progress_without_poll_and_reconnect(room):
    guest = room.join("Friend", "🐼")
    room.start(room.host_token, room.table.config, room.version)
    for _ in range(200):
        if room.table.state["type"] == "hand_complete":
            break
        room.test_clock[0] += 100
        room.tick()  # no browser GETs needed
    assert room.table.state["type"] == "hand_complete"
    assert sum(room.table.stacks.values()) == 60000
    assert room.table.history.summary()["hands"] == 1
    record = room.table.history.records()[0]
    assert any(d["source"] == "human_timeout" for d in record["decisions"])
    assert record["participants"]["ai1"]["name"] == "Friend"
    view = room.view(guest)  # reconnect to same seat
    assert view["viewer"] == "ai1"
    assert all(
        not p["cards"]
        for p in view["players"]
        if p["status"] == "folded" and p["id"] != view["viewer"]
    )
    with pytest.raises(PermissionError):
        room.next_hand(guest, room.version)
    room.next_hand(room.host_token, room.version)
    assert room.table.hand == 2


def test_stale_action_and_room_isolation(room):
    other = Room("OTHER1", "Other host", "🐺")
    with pytest.raises(PermissionError):
        other.view(room.host_token)
    tokens = [room.host_token] + [room.join(str(i), "🐼") for i in range(5)]
    with pytest.raises(ValueError):
        room.join("extra", "🐼")
    room.start(tokens[0], room.table.config, room.version)
    actor = room.table.engine.players[room.table.state["seat_to_act"]].bot_id
    token = next(t for t in tokens if room.members[t] == actor)
    old = room.version
    room.act(token, old, {"action": "call"})
    with pytest.raises(ValueError):
        room.act(token, old, {"action": "call"})
    with pytest.raises(ValueError):
        room.lobby(tokens[0], room.version)


def test_rebuy_between_hands_preserves_result(room):
    host = room.host_token
    room.start(host, room.table.config, room.version)
    with pytest.raises(ValueError):
        room.rebuy(host, room.version)
    # Controlled completed-hand fixture: host has lost all chips.
    room.table.state = {
        "type": "hand_complete",
        "final_stacks": dict.fromkeys(room.table.ids, 10000),
    }
    room.table.state["final_stacks"]["you"] = 0
    room.table.stacks.update(room.table.state["final_stacks"])
    room.table.saved = True
    old = room.version
    room.rebuy(host, old)
    assert room.table.stacks["you"] == 10000
    assert room.table.state["final_stacks"]["you"] == 0
    assert not room.view(host)["can_rebuy"]
    assert room.view(host)["players"][0]["status"] == "rebought"
    with pytest.raises(ValueError):
        room.rebuy(host, old)
    with pytest.raises(ValueError):
        room.rebuy(host, room.version)
    import sqlite3

    with sqlite3.connect(room.table.history.path) as db:
        assert db.execute("SELECT count(*) FROM rebuys").fetchone()[0] == 1
    room.next_hand(host, room.version)
    assert room.table.engine._starting_stacks["you"] == 10000


def test_auto_next_pause_resume(room):
    host = room.host_token
    guest = room.join("Friend", "🐼")
    room.start(host, room.table.config, room.version)
    room.set_pause(host, room.version, True)
    for _ in range(200):
        if room.table.state["type"] == "hand_complete":
            break
        room.test_clock[0] += 100
        room.tick()
    assert room.table.state["type"] == "hand_complete"
    hand = room.table.hand
    room.test_clock[0] += 100
    room.tick()
    assert room.table.hand == hand
    with pytest.raises(PermissionError):
        room.set_pause(guest, room.version, False)
    room.set_pause(host, room.version, False)
    assert room.view(host)["next_in"] == 15
    room.test_clock[0] += 14
    room.tick()
    assert room.table.hand == hand
    room.test_clock[0] += 1
    room.tick()
    assert room.table.hand == hand + 1


def test_rebuy_during_other_players_hand_and_ai_auto(room):
    host = room.host_token
    room.start(host, room.table.config, room.version)
    t = room.table
    # Host eliminated last hand, while a new hand runs without their seat.
    t.stacks["you"] = 0
    t.engine.players = [p for p in t.engine.players if p.bot_id != "you"]
    t.state["seat_to_act"] = 0
    deadline = room.due
    assert room.view(host)["can_rebuy"]
    room.rebuy(host, room.version)
    assert room.due == deadline  # don't reset the current actor's timer
    assert not any(p.bot_id == "you" for p in t.engine.players)
    assert room.view(host)["players"][0]["stack"] == 10000
    assert not room.can_rebuy("you")
    t.stacks["ai2"] = 0
    t.state = {"type": "hand_complete"}
    t.saved = True
    room.schedule()
    assert t.stacks["ai2"] == 10000
    count = len(room.rebuys)
    room.schedule()
    assert len(room.rebuys) == count
    assert room.rebuys[-1]["automatic"]


def test_host_out_rebuy_archive_and_finances(room):
    host = room.host_token
    room.start(host, room.table.config, room.version)
    t = room.table
    # Previous completed hand eliminated host, transferring their chips to AI 1.
    t.stacks["you"] = 0
    t.stacks["ai1"] = 20000
    t.state = {"type": "hand_complete"}
    t.saved = True
    room.next_hand(host, room.version)
    assert not any(p.bot_id == "you" for p in t.engine.players)
    room.rebuy(host, room.version)
    finance = room.finances()
    host_row = finance["rows"][0]
    assert host_row["total_buyin"] == 20000
    assert host_row["stack"] == 10000
    assert host_row["profit"] == -10000
    assert finance["total_profit"] == 0
    room.set_pause(host, room.version, True)
    for _ in range(200):
        if t.state["type"] == "hand_complete":
            break
        room.test_clock[0] += 100
        room.tick()
    assert not room.error
    assert not t.save_error
    assert t.saved
    history = t.history.records()
    assert len(history) == 1
    assert "you" not in history[0]["chip_delta"]
    assert t.history.summary()["net_chips"] == 0
    assert room.finances()["total_profit"] == 0
    room.next_hand(host, room.version)
    assert any(p.bot_id == "you" for p in t.engine.players)
    assert t.engine._starting_stacks["you"] == 10000


def test_host_speed_and_guest_finances(room):
    host = room.host_token
    guest = room.join("Friend", "🐼")
    room.start(host, room.table.config, room.version)
    deadline = room.due
    with pytest.raises(PermissionError):
        room.set_speed(guest, room.version, 3)
    with pytest.raises(ValueError):
        room.set_speed(host, room.version, 0)
    room.set_speed(host, room.version, 3)
    assert room.due == deadline
    assert room.view(guest)["ai_seconds"] == 3
    assert room.view(host)["finances"] == room.view(guest)["finances"]
    assert len(room.view(guest)["finances"]["rows"]) == 6


def test_host_configurable_break(room):
    host = room.host_token
    guest = room.join("Friend", "🐼")
    with pytest.raises(PermissionError):
        room.set_break(guest, room.version, 30)
    for invalid in [0, 121, 5.5, True, "15"]:
        with pytest.raises(ValueError):
            room.set_break(host, room.version, invalid)
    room.start(host, room.table.config, room.version)
    due = room.due
    room.set_break(host, room.version, 30)
    assert room.due == due
    assert room.view(guest)["break_seconds"] == 30
    room.next_due = room.clock() + 10
    room.set_break(host, room.version, 45)
    assert room.next_due == room.clock() + 45
    room.set_pause(host, room.version, True)
    room.set_break(host, room.version, 20)
    assert room.next_due is None
    assert room.auto_paused
