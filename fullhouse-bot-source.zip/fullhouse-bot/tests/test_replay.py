import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from local_play.history import History
from local_play.replay import build_replay
from local_play.server import Table


def test_replay_stacks_board_and_privacy(tmp_path):
    history = History(tmp_path / "history.sqlite3")
    table = Table(policy=lambda s: {"action": "all_in"}, history=history)
    while not table.view()["done"]:
        table.step({"action": "all_in"} if table.view()["actor"] == "you" else None)
    hand = history.records()[0]
    replay = build_replay(hand, "you")
    frames = replay["frames"]
    assert {f["street"] for f in frames} == {"preflop", "flop", "turn", "river"}
    revealed = False
    previous = 0
    for frame in frames:
        assert sum(p["stack"] for p in frame["players"]) + frame["pot"] == 60000
        assert len(frame["board"]) >= previous
        previous = len(frame["board"])
        if frame["label"] == "摊牌":
            revealed = True
        if not revealed:
            assert all(not p["cards"] for p in frame["players"] if p["id"] != "you")
        assert (
            next(p["cards"] for p in frame["players"] if p["id"] == "you")
            == hand["hole_cards"]["you"]
        )
    assert {p["id"]: p["stack"] for p in frames[-1]["players"]} == hand["result"][
        "final_stacks"
    ]
    assert frames[-1]["pot"] == 0


def test_folded_cards_never_revealed(tmp_path):
    history = History(tmp_path / "history.sqlite3")
    table = Table(policy=lambda s: {"action": "fold"}, history=history)
    while not table.view()["done"]:
        table.step({"action": "fold"} if table.view()["actor"] == "you" else None)
    for frame in build_replay(history.records()[0], "you")["frames"]:
        assert all(not p["cards"] for p in frame["players"] if p["id"] != "you")
        assert frame["board"] == []
