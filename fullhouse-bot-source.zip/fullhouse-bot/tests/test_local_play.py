"""Gameplay regressions for the human-facing table."""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import pytest

from local_play.server import Table, TableEngine


def test_private_cards_and_human_turn():
    table = Table(policy=lambda s: {"action": "call"})
    while table.view()["actor"] != "you":
        table.step()
    view = table.view()
    assert len(view["players"][0]["cards"]) == 2
    assert all(not p["cards"] for p in view["players"][1:])
    with pytest.raises(ValueError):
        table.step({"action": "raise", "amount": 1})
    with pytest.raises(ValueError):
        table.engine.apply_action((table.engine.pending + 1) % 6, {"action": "fold"})


def test_short_allin_requires_call_but_does_not_reopen():
    e = TableEngine(
        "short",
        ["a", "b", "c"],
        starting_stacks={"a": 1000, "b": 150, "c": 1000},
        seed=2,
    )
    s = e.start_hand()  # a is button, first to act
    s = e.apply_action(s["seat_to_act"], {"action": "call"})
    s = e.apply_action(s["seat_to_act"], {"action": "all_in"})
    s = e.apply_action(s["seat_to_act"], {"action": "call"})
    assert s["seat_to_act"] == 0 and s["amount_owed"] == 50
    assert not s["can_raise"]
    s = e.apply_action(0, {"action": "call"})
    assert s["street"] == "flop"


def test_full_raise_and_chip_conservation_over_many_hands():
    table = Table(policy=lambda s: {"action": "call"})
    for _ in range(12):
        turns = 0
        while not table.view()["done"]:
            turns += 1
            assert turns < 200
            if table.view()["actor"] == "you":
                legal = table.view()["legal"]
                action = {"action": "call"}
                if (
                    turns == 4
                    and legal["can_raise"]
                    and legal["max_raise_to"] >= legal["min_raise_to"]
                ):
                    action = {"action": "raise", "amount": legal["min_raise_to"]}
                table.step(action)
            else:
                table.step()
        assert sum(p["stack"] for p in table.view()["players"]) == 60000
        if not table.view()["can_next"]:
            break
        table.next_hand()


def test_allin_runout_and_elimination():
    table = Table(policy=lambda s: {"action": "all_in"})
    while not table.view()["done"]:
        table.step({"action": "all_in"} if table.view()["actor"] == "you" else None)
    assert len(table.view()["board"]) == 5
    assert sum(table.stacks.values()) == 60000
    assert table.view()["winners"]


def test_raise_reopens_and_blind_allins_finish():
    engine = TableEngine("raise", ["a", "b", "c"], seed=3)
    s = engine.start_hand()
    s = engine.apply_action(s["seat_to_act"], {"action": "raise", "amount": 300})
    assert s["current_bet"] == 300
    assert s["min_raise_to"] == 500
    assert s["can_raise"]
    short = TableEngine(
        "blinds", ["a", "b"], starting_stacks={"a": 25, "b": 50}, seed=4
    )
    assert short.start_hand()["type"] == "hand_complete"
    assert sum(p.stack for p in short.players) == 75


def test_style_layer_and_setup_validation():
    import numpy as np
    from local_play.personalities import adjust_strategy
    probs = np.array([.25, .4, .25, .1, 0.])
    state = {'street': 'preflop', 'pot': 150, 'amount_owed': 100, 'your_stack': 10000}
    tight = adjust_strategy(probs, state, 'tag')
    loose = adjust_strategy(probs, state, 'lag')
    assert tight[0] > loose[0]
    assert tight[4] == loose[4] == 0
    assert np.isclose(tight.sum(), 1)
    np.testing.assert_array_equal(adjust_strategy(probs, state, 'original'), probs)
    table = Table(require_setup=True)
    with pytest.raises(ValueError):
        table.step()
    revision = table.revision
    with pytest.raises(ValueError):
        table.reset([{'style': 'unknown', 'avatar': 'x'}] * 5)
    assert table.revision == revision
    config = [{'style': 'lag', 'avatar': '🐺'}] * 5
    table.reset(config)
    assert table.view()['configured']
    assert all(p['style_label'] == '松凶' for p in table.view()['players'][1:])
    # Exercise the real model with the configured style through a complete hand.
    for _ in range(200):
        if table.view()['done']:
            break
        table.step({'action': 'call'} if table.view()['actor'] == 'you' else None)
    assert table.view()['done']
    assert sum(table.stacks.values()) == 60000


def test_persistent_history_and_training_export(tmp_path):
    import json
    from local_play.history import History
    path = tmp_path / 'history.sqlite3'
    archive = History(path)
    table = Table(policy=lambda s: {'action': 'call'}, history=archive)
    assert archive.summary()['hands'] == 0
    while not table.view()['done']:
        table.step({'action': 'call'} if table.view()['actor'] == 'you' else None)
    table.persist_hand()
    loaded = History(path)
    assert loaded.summary()['hands'] == 1
    hand = loaded.records()[0]
    assert sum(hand['chip_delta'].values()) == 0
    assert len(hand['hole_cards']) == 6
    rows = [json.loads(line) for line in loaded.export(True).decode().splitlines()]
    assert rows
    for row in rows:
        assert all(p['hole_cards'] is None for p in row['observation']['players'])
        assert len(row['observation']['your_cards']) == 2
        assert 'hole_cards' not in row
        assert row['hand_return_chips'] == hand['chip_delta'][row['player']]
    table.reset()
    assert loaded.summary()['hands'] == 1


def test_showdown_odds_and_runout():
    from local_play.equity import showdown_odds
    hands = {'you': ['As', 'Ad'], 'ai1': ['Ks', 'Kd']}
    odds = showdown_odds(hands, ['2c', '3d', '7h', '8s', '9c'])
    assert odds['exact'] and odds['players'][0]['win'] == 1
    tie = showdown_odds(hands, ['Tc', 'Jc', 'Qc', 'Kc', 'Ac'])
    assert all(p['tie'] == 1 and p['equity'] == .5 for p in tie['players'])
    flop = showdown_odds(hands, ['2c', '3d', '7h'])
    assert abs(sum(p['equity'] for p in flop['players']) - 1) < 1e-9
    table = Table(policy=lambda s: {'action': 'all_in'})
    while not table.view()['done']:
        assert not table.view()['runout_odds']
        table.step({'action': 'all_in'} if table.view()['actor'] == 'you' else None)
    assert set(table.view()['runout_odds']) == {'0', '3', '4', '5'}
